<?php

include_once 'lib/setup-blade.php';

echo $blade->run("index", array());
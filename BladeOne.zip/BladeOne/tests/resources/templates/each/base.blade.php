@each('each.item', $list, 'list_item')

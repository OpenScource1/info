@extends('extends.base')

@section('from_child')
    From Child({{$globalme}})...
@endsection
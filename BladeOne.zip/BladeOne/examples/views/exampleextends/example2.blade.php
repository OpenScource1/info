<h1> hello-world.blade.php</h1>
@extends('exampleextends.layout')

@section('content')
    <hr>
    <h2>content</h2>
    {{$content}}<br>
    <hr>
@endsection
It is a local variable {{$localvar}}<br>

it is a shared variable {{$globalvar}}<br>
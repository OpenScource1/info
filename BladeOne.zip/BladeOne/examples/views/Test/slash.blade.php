{{$var}}
<br>
{!! $var !!}
<br>
<a href="#{{$var}}">go to var</a>
<a href="#aaa/bbb\\aaa aa%2Fbbb%5Caaa">go to var</a>

<pre>
{{$var}}

{!! $var !!}
    
<a href="#{{$var}}">go to var</a>
<a href="#aaa/bbb\\aaa aa%%2Fbbb%5Caaa">go to var</a>
    
</pre>
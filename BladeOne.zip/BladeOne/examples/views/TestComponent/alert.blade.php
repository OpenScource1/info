<div class="alert alert-danger" style="background-color: {!! $color  !!}; padding-left: 100px;border: black 1px solid">
    <div>title:{!! $title !!}</div>
    <div>myglobal:{!! $myglobal !!}</div>
    {!! $slot !!}
    <div>end title:{!! $title !!}</div>
</div>
<br>
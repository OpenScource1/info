<?php

use eftec\bladeone\BladeOneLang;

/**
 * @see \$blade is defined on /BladeOne/examples/testlang.php
 */
$blade::$dictionary=array(
    'Hat'=>'Sombrero'
    ,'Cat'=>'chat'
    ,'Cats'=>'Chats'
    ,'%s is a nice cat'=>'%s est un gentil chat'

);
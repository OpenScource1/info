<?php

use eftec\bladeone\BladeOneLang;

/**
 * @see \$blade is defined on /BladeOne/examples/testlang.php
 */
$blade::$dictionary=array(
    'Hat'=>'Sombrero'
    ,'Cat'=>'Gato'
    ,'Cats'=>'Gatos' // plural
    ,'%s is a nice cat'=>'%s es un buen gato'
);

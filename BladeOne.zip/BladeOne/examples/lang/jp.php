<?php

/**
 * @see \myBlade is defined on /BladeOne/examples/testlang.php
 */
myBlade::$dictionary=[
    'Hat'=>'帽子'
    ,'Cat'=>'ネコ' // Neko is japanese for cat japanese.
    ,'Cats'=>'猫' // plural
    ,'%s is a nice cat'=>'%sは素敵な猫です'

];

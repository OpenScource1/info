<?php
/**
 * Created by PhpStorm.
 * User: jorge
 * Date: 12-07-2018
 * Time: 8:46 AM
 */

namespace App\Services\MetricsService;


class Metric
{

    public function monthlyRevenue() {
        return "We increased our monthly revenue by $1";
    }
}
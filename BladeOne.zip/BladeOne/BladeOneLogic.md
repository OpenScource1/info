#BladeOneLogic extension library (optional)

Requires: BladeOne

For using this tag, the code requires to use the class BladeOneLogic
 
## Defintion of Blade Template
For using this tag, the code requires to use the class BladeOneLogic that extends the class BladeOne.
The code extends the class BladeOneHtml by creating a daisy chain.

